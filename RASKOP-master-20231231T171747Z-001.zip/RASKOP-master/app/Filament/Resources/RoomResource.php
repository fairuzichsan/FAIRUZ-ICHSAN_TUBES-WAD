<?php

namespace App\Filament\Resources;

use App\Filament\Resources\RoomResource\Pages;
use App\Filament\Resources\RoomResource\RelationManagers;
use App\Models\Room;
use Filament\Forms;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class RoomResource extends Resource
{
    protected static ?string $model = Room::class;

    protected static ?string $navigationIcon = 'heroicon-o-home-modern';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('room_name')->label('nama ruangan')->required()->columnSpanFull(),
                TextInput::make('slug')->label('slug ruangan')->required()->columnSpanFull(),
                TextInput::make('capacity')->label('kapasitas ruangan')->numeric()->required()->columnSpanFull(),
                MarkdownEditor::make('description')->label('deskripsi ruangan')->required()->columnSpanFull(),
                FileUpload::make('image_url')->required()->image()->name('Cover Gambar')->disk('cloudinary')->directory('room')->columnSpanFull(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('room_name')->label('nama ruangan'),
                Tables\Columns\TextColumn::make('capacity')->label('kapasitas ruangan'),
                Tables\Columns\ImageColumn::make('image_url')->label('gambar ruangan')
                ->disk('cloudinary')
                ,
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRooms::route('/'),
            'create' => Pages\CreateRoom::route('/create'),
            'edit' => Pages\EditRoom::route('/{record}/edit'),
        ];
    }
}
